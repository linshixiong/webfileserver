$(document).ready(function(){
		$("div a").bind("click", function(e){
		var action= $(this).attr("action");
		var data= $(this).attr("data");
		alert("action="+action+",data="+data);
	}); 
});

function mousePosition(ev){ 
	if(ev.pageX || ev.pageY){ 
		return {x:ev.pageX, y:ev.pageY}; 
	} 
	return { 
		x:ev.clientX + document.body.scrollLeft - document.body.clientLeft, 
		y:ev.clientY + document.body.scrollTop - document.body.clientTop 
	}; 
} 

function doAction(action,data){
	var xhr = new XMLHttpRequest();

	xhr.addEventListener("load", sendComplete, false);
	xhr.addEventListener("error", sendComplete, false);
	xhr.open("POST","/");
	xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");  
	xhr.send("remote_action="+action+"&data="+data);
}

 function sendComplete(evt) {
	
}